# PandownloadFake

虚假的Pandownload验证“服务器”

Pandownload无法启动的原因是其服务器关闭了，但软件的下载百度网盘资源功能是正常的，所以搭建了这个伪服务端代替Pandownload服务器，使得软件可以正常启动。

添加hosts修改pandownload.com的指向，到GithubPages任何一个节点IP都可

185.199.108.153/185.199.109.153/185.199.111.153/185.199.110.153这四个中的任何一个都可以

方法及文件由<https://www.hostloc.com/thread-675311-1-1.html>提供

不知道此方法能用多久，且用且珍惜了。

## 文件更新

目前更新到了最新的文件内容，感谢[Womsxd](https://github.com/Womsxd)提供的文件。

原仓库地址：<https://github.com/Womsxd/pandownload.com_Pages_Backup>

## 提示

2020/4/17: 经目前监测，Pandownload.com官方服务似乎已恢复，不使用本方案软件也可以正常打开，在这种情况下请删除相关hosts配置恢复原状，使用官方的服务。本Repo仅供紧急情况下使用。
